
const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.use("/admin", express.static("admin"));
app.use(bodyParser.json());

const DATA_FILE = "./data/posts.json";

const ADMIN = {
    username: "boostoraAdmin",
    password: "Boostora@2026"
};

const JWT_SECRET = "NC8zXWi4JwG8Pi0n05kTImVugoBEt4rH";

function getPosts(){
    return JSON.parse(fs.readFileSync(DATA_FILE,"utf-8"));
}

function savePosts(posts){
    fs.writeFileSync(DATA_FILE, JSON.stringify(posts,null,2));
}

app.post("/api/login",(req,res)=>{
    const {username,password}=req.body;

    if(username!==ADMIN.username || password!==ADMIN.password){
        return res.status(401).send("Invalid login");
    }

    const token = jwt.sign({user:username},JWT_SECRET,{expiresIn:"2h"});
    res.json({token});
});

function auth(req,res,next){
    const token=req.headers["authorization"];
    if(!token) return res.sendStatus(403);

    jwt.verify(token,JWT_SECRET,(err)=>{
        if(err) return res.sendStatus(403);
        next();
    });
}

app.get("/api/posts",(req,res)=>res.json(getPosts()));

app.post("/api/posts",auth,(req,res)=>{
    const posts=getPosts();
    const post={
        id:Date.now(),
        title:req.body.title,
        content:req.body.content,
        date:new Date()
    };
    posts.push(post);
    savePosts(posts);
    res.json(post);
});

app.delete("/api/posts/:id",auth,(req,res)=>{
    let posts=getPosts().filter(p=>p.id!=req.params.id);
    savePosts(posts);
    res.json({ok:true});
});

app.listen(PORT,()=>console.log("Boostora running"));
