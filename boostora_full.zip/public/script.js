
fetch("/api/posts")
.then(r=>r.json())
.then(data=>{
 const c=document.getElementById("posts");
 data.forEach(p=>{
  const d=document.createElement("div");
  d.className="post";
  d.innerHTML=`<h2>${p.title}</h2><p>${p.content}</p>`;
  c.appendChild(d);
 });
});
